from qulacs_core.gate import *
