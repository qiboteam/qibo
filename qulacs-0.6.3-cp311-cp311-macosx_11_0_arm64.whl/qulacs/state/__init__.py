from qulacs_core.state import *
