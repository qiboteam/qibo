from qulacs_core.observable import *
