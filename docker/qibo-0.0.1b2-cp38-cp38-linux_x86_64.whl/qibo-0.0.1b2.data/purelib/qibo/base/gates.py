# -*- coding: utf-8 -*-
# @authors: S. Carrazza and A. Garcia
import sys
from typing import Dict, List, Optional, Sequence, Tuple

QASM_GATES = {"h": "H", "x": "X", "y": "Y", "z": "Z",
              "rx": "RX", "ry": "RY", "rz": "RZ",
              "cx": "CNOT", "swap": "SWAP",
              "crz": "CZPow", "ccx": "TOFFOLI"}
PARAMETRIZED_GATES = {"rx", "ry", "rz", "crz"}


class Gate(object):
    """The base class for gate implementation.

    All gates should inherit this class.

    Attributes:
        name: Name of the gate.
        target_qubits: Tuple with ids of target qubits.
    """

    def __init__(self):
        self.name = None
        self.is_channel = False
        self.is_controlled_by = False
        self.is_special_gate = False
        # special gates are ``CallbackGate`` and ``Flatten``

        self._init_args = []
        self._init_kwargs = {}

        self._target_qubits = tuple()
        self._control_qubits = set()

        self._nqubits = None
        self._nstates = None

    @property
    def target_qubits(self) -> Tuple[int]:
        """Tuple with ids of target qubits."""
        return self._target_qubits

    @property
    def control_qubits(self) -> Tuple[int]:
        """Tuple with ids of control qubits sorted in increasing order."""
        return tuple(sorted(self._control_qubits))

    @property
    def qubits(self) -> Tuple[int]:
        """Tuple with ids of all qubits (control and target) that the gate acts."""
        return self.control_qubits + self.target_qubits

    def _set_target_qubits(self, qubits: Sequence[int]):
        """Helper method for setting target qubits."""
        self._target_qubits = tuple(qubits)
        if len(self._target_qubits) != len(set(qubits)):
            repeated = self._find_repeated(qubits)
            raise ValueError("Target qubit {} was given twice for gate {}."
                             "".format(repeated, self.name))

    def _set_control_qubits(self, qubits: Sequence[int]):
        """Helper method for setting control qubits."""
        self._control_qubits = set(qubits)
        if len(self._control_qubits) != len(qubits):
            repeated = self._find_repeated(qubits)
            raise ValueError("Control qubit {} was given twice for gate {}."
                             "".format(repeated, self.name))

    @target_qubits.setter
    def target_qubits(self, qubits: Sequence[int]):
        """Sets control qubits tuple."""
        self._set_target_qubits(qubits)
        self._check_control_target_overlap()

    @control_qubits.setter
    def control_qubits(self, qubits: Sequence[int]):
        """Sets control qubits set."""
        self._set_control_qubits(qubits)
        self._check_control_target_overlap()

    def set_targets_and_controls(self, target_qubits: Sequence[int],
                                 control_qubits: Sequence[int]):
        """Sets target and control qubits simultaneously.

        This is used for the reduced qubit updates in the distributed circuits
        because using the individual setters may raise errors due to temporary
        overlap of control and target qubits.
        """
        self._set_target_qubits(target_qubits)
        self._set_control_qubits(control_qubits)
        self._check_control_target_overlap()

    @staticmethod
    def _find_repeated(qubits: Sequence[int]) -> int:
        """Finds the first qubit id that is repeated in a sequence of qubit ids."""
        temp_set = set()
        for qubit in qubits:
            if qubit in temp_set:
                return qubit
            temp_set.add(qubit)

    def _check_control_target_overlap(self):
        """Checks that there are no qubits that are both target and controls."""
        common = set(self._target_qubits) & self._control_qubits
        if common:
            raise ValueError("{} qubits are both targets and controls for "
                             "gate {}.".format(common, self.name))

    @property
    def nqubits(self) -> int:
        """Number of qubits in the circuit that the gate is part of.

        This is set automatically when the gate is added on a circuit or
        when the gate is called on a state. The user should not set this.
        """
        if self._nqubits is None:
            raise ValueError("Accessing number of qubits for gate {} but "
                             "this is not yet set.".format(self))
        return self._nqubits

    @property
    def nstates(self) -> int:
        if self._nstates is None:
            raise ValueError("Accessing number of qubits for gate {} but "
                             "this is not yet set.".format(self))
        return self._nstates

    @nqubits.setter
    def nqubits(self, n: int):
        """Sets the total number of qubits that this gate acts on.

        This setter is used by `circuit.add` if the gate is added in a circuit
        or during `__call__` if the gate is called directly on a state.
        The user is not supposed to set `nqubits` by hand.
        """
        if self._nqubits is not None:
            raise RuntimeError("The number of qubits for this gates is already "
                               "set to {}.".format(self._nqubits))
        self._nqubits = n
        self._nstates = 2**n
        self._prepare()

    def _prepare(self): # pragma: no cover
        """Prepares the gate for application to state vectors.

        Called automatically by the ``nqubits`` setter.
        Calculates the ``matrix`` required to apply the gate to state vectors.
        This is not necessarily the same as the unitary matrix of the gate.
        """
        raise NotImplementedError

    def commutes(self, gate: "Gate") -> bool:
        """Checks if two gates commute.

        Args:
            gate: Gate to check if it commutes with the current gate.

        Returns:
            ``True`` if the gates commute, otherwise ``False``.
        """
        if self.is_special_gate or gate.is_special_gate:
            return False
        t1 = set(self.target_qubits)
        t2 = set(gate.target_qubits)
        a = self.__class__ == gate.__class__ and t1 == t2
        b = not (t1 & set(gate.qubits) or t2 & set(self.qubits))
        return a or b

    def controlled_by(self, *qubits: int) -> "Gate":
        """Controls the gate on (arbitrarily many) qubits.

        Args:
            *qubits (int): Ids of the qubits that the gate will be controlled on.

        Returns:
            A :class:`qibo.base.gates.Gate` object in with the corresponding gate being
            controlled in the given qubits.
        """
        if self.control_qubits:
            raise RuntimeError("Cannot use `controlled_by` method on gate {} "
                               "because it is already controlled by {}."
                               "".format(self, self.control_qubits))
        if self._nqubits is not None:
            raise RuntimeError("Cannot use controlled_by on a gate that is "
                               "part of a Circuit or has been called on a "
                               "state.")
        if qubits:
            self.is_controlled_by = True
            self.control_qubits = qubits
        return self

    def decompose(self, *free) -> List["Gate"]:
        """Decomposes multi-control gates to gates supported by OpenQASM.

        Decompositions are based on `arXiv:9503016 <https://arxiv.org/abs/quant-ph/9503016>`_.

        Args:
            free: Ids of free qubits to use for the gate decomposition.

        Returns:
            List with gates that have the same effect as applying the original gate.
        """
        # FIXME: Implement this method for all gates not supported by OpenQASM.
        # If the method is not implemented this returns a deep copy of the
        # original gate
        return [self.__class__(*self._init_args, **self._init_kwargs)]

    def __call__(self, state, is_density_matrix): # pragma: no cover
        """Acts with the gate on a given state vector:

        Args:
            state: Input state vector.
                The type and shape of this depend on the backend.

        Returns:
            The state vector after the action of the gate.
        """
        raise NotImplementedError


class H(Gate):
    """The Hadamard gate.

    Args:
        q (int): the qubit id number.
    """

    def __init__(self, q):
        super(H, self).__init__()
        self.name = "h"
        self.target_qubits = (q,)
        self._init_args = [q]


class X(Gate):
    """The Pauli X gate.

    Args:
        q (int): the qubit id number.
    """
    _MODULE = sys.modules[__name__]

    def __init__(self, q):
        super(X, self).__init__()
        self.name = "x"
        self.target_qubits = (q,)
        self._init_args = [q]

    def controlled_by(self, *q):
        """Fall back to CNOT and Toffoli if controls are one or two."""
        if len(q) == 1:
            gate = getattr(self._MODULE, "CNOT")(q[0], self.target_qubits[0])
        elif len(q) == 2:
            gate = getattr(self._MODULE, "TOFFOLI")(q[0], q[1], self.target_qubits[0])
        else:
            gate = super(X, self).controlled_by(*q)
        return gate

    def decompose(self, *free: int, use_toffolis: bool = True) -> List[Gate]:
        """Decomposes multi-control ``X`` gate to one-qubit, ``CNOT`` and ``TOFFOLI`` gates.

        Args:
            free: Ids of free qubits to use for the gate decomposition.
            use_toffolis: If ``True`` the decomposition contains only ``TOFFOLI`` gates.
                If ``False`` a congruent representation is used for ``TOFFOLI`` gates.
                See :class:`qibo.base.gates.TOFFOLI` for more details on this representation.

        Returns:
            List with one-qubit, ``CNOT`` and ``TOFFOLI`` gates that have the
            same effect as applying the original multi-control gate.
        """
        if set(free) & set(self.qubits):
            raise ValueError("Cannot decompose multi-control X gate if free "
                             "qubits coincide with target or controls.")
        if self._nqubits is not None:
            for q in free:
                if q >= self.nqubits:
                    raise ValueError("Gate acts on {} qubits but {} was given "
                                     "as free qubit.".format(self.nqubits, q))

        controls = self.control_qubits
        target = self.target_qubits[0]
        m = len(controls)
        if m < 3:
            return [self.__class__(target).controlled_by(*controls)]

        decomp_gates = []
        n = m + 1 + len(free)
        TOFFOLI = self._MODULE.TOFFOLI
        if (n >= 2 * m - 1) and (m >= 3):
            gates1 = [TOFFOLI(controls[m - 2 - i],
                              free[m - 4 - i],
                              free[m - 3 - i]
                              ).congruent(use_toffolis=use_toffolis)
                      for i in range(m - 3)]
            gates2 = TOFFOLI(controls[0], controls[1], free[0]
                             ).congruent(use_toffolis=use_toffolis)
            first_toffoli = TOFFOLI(controls[m - 1], free[m - 3], target)

            decomp_gates.append(first_toffoli)
            for gates in gates1:
                decomp_gates.extend(gates)
            decomp_gates.extend(gates2)
            for gates in gates1[::-1]:
                decomp_gates.extend(gates)

        elif len(free) >= 1:
            m1 = n // 2
            free1 = controls[m1:] + (target,) + tuple(free[1:])
            x1 = self.__class__(free[0]).controlled_by(*controls[:m1])
            part1 = x1.decompose(*free1, use_toffolis=use_toffolis)

            free2 = controls[:m1] + tuple(free[1:])
            controls2 = controls[m1:] + (free[0],)
            x2 = self.__class__(target).controlled_by(*controls2)
            part2 = x2.decompose(*free2, use_toffolis=use_toffolis)

            decomp_gates = [*part1, *part2]

        else: # pragma: no cover
            raise NotImplementedError("X decomposition is not implemented for "
                                      "zero free qubits.")

        decomp_gates.extend(decomp_gates)
        return decomp_gates


class Y(Gate):
    """The Pauli Y gate.

    Args:
        q (int): the qubit id number.
    """

    def __init__(self, q):
        super(Y, self).__init__()
        self.name = "y"
        self.target_qubits = (q,)
        self._init_args = [q]


class Z(Gate):
    """The Pauli Z gate.

    Args:
        q (int): the qubit id number.
    """

    _MODULE = sys.modules[__name__]

    def __init__(self, q):
        super(Z, self).__init__()
        self.name = "z"
        self.target_qubits = (q,)
        self._init_args = [q]

    def controlled_by(self, *q):
        """Fall back to CZ if control is one."""
        if len(q) == 1:
            gate = getattr(self._MODULE, "CZ")(q[0], self.target_qubits[0])
        else:
            gate = super(Z, self).controlled_by(*q)
        return gate


class M(Gate):
    """The Measure Z gate.

    Args:
        *q (int): id numbers of the qubits to measure.
            It is possible to measure multiple qubits using ``gates.M(0, 1, 2, ...)``.
            If the qubits to measure are held in an iterable (eg. list) the ``*``
            operator can be used, for example ``gates.M(*[0, 1, 4])`` or ``gates.M(*range(5))``.
        register_name: Optional name of the register to distinguish it from
            other registers when used in circuits.
    """

    def __init__(self, *q, register_name: Optional[str] = None):
        super(M, self).__init__()
        self.name = "measure"
        self.target_qubits = q
        self.register_name = register_name

        self._init_args = q
        self._init_kwargs = {"register_name": register_name}

        self._unmeasured_qubits = None # Tuple
        self._reduced_target_qubits = None # List

    def _add(self, qubits: Tuple[int]):
        """Adds target qubits to a measurement gate.

        This method is only used for creating the global measurement gate used
        by the `models.Circuit`.
        The user is not supposed to use this method and a `ValueError` is
        raised if he does so.

        Args:
            qubits: Tuple of qubit ids to be added to the measurement's qubits.
        """
        if self._unmeasured_qubits is not None:
            raise RuntimeError("Cannot add qubits to a measurement gate that "
                               "was executed.")
        self.target_qubits += qubits

    def _set_unmeasured_qubits(self):
        if self._nqubits is None:
            raise ValueError("Cannot calculate set of unmeasured qubits if "
                             "the number of qubits in the circuit is unknown.")
        if self._unmeasured_qubits is not None:
            raise RuntimeError("Cannot recalculate unmeasured qubits.")
        target_qubits = set(self.target_qubits)
        unmeasured_qubits = []
        reduced_target_qubits = dict()
        for i in range(self.nqubits):
            if i in target_qubits:
                reduced_target_qubits[i] = i - len(unmeasured_qubits)
            else:
                unmeasured_qubits.append(i)

        self._unmeasured_qubits = tuple(unmeasured_qubits)
        self._reduced_target_qubits = list(reduced_target_qubits[i]
                                           for i in self.target_qubits)

    @property
    def unmeasured_qubits(self) -> Tuple[int]:
        """Tuple with ids of unmeasured qubits sorted in increasing order.

        This is useful when tracing out unmeasured qubits to calculate
        probabilities.
        """
        if self._unmeasured_qubits is None:
            self._set_unmeasured_qubits()
        return self._unmeasured_qubits

    @property
    def reduced_target_qubits(self) -> List[int]:
        if self._unmeasured_qubits is None:
            self._set_unmeasured_qubits()
        return self._reduced_target_qubits

    def controlled_by(self, *q):
        """"""
        raise NotImplementedError("Measurement gates cannot be controlled.")


class RX(Gate):
    """Rotation around the X-axis of the Bloch sphere.

    Corresponds to the following unitary matrix

    .. math::
        \\begin{pmatrix}
        \\cos \\frac{\\theta }{2}  &
        -i\\sin \\frac{\\theta }{2} \\\\
        -i\\sin \\frac{\\theta }{2}  &
        \\cos \\frac{\\theta }{2} \\\\
        \\end{pmatrix}

    Args:
        q (int): the qubit id number.
        theta (float): the rotation angle.
    """

    def __init__(self, q, theta):
        super(RX, self).__init__()
        self.name = "rx"
        self.target_qubits = (q,)
        self.theta = theta

        self._init_args = [q]
        self._init_kwargs = {"theta": theta}


class RY(Gate):
    """Rotation around the Y-axis of the Bloch sphere.

    Corresponds to the following unitary matrix

    .. math::
        \\begin{pmatrix}
        \\cos \\frac{\\theta }{2}  &
        -\\sin \\frac{\\theta }{2} \\\\
        \\sin \\frac{\\theta }{2}  &
        \\cos \\frac{\\theta }{2} \\\\
        \\end{pmatrix}

    Args:
        q (int): the qubit id number.
        theta (float): the rotation angle.
    """

    def __init__(self, q, theta):
        super(RY, self).__init__()
        self.name = "ry"
        self.target_qubits = (q,)
        self.theta = theta

        self._init_args = [q]
        self._init_kwargs = {"theta": theta}


class RZ(Gate):
    """Rotation around the X-axis of the Bloch sphere.

    Corresponds to the following unitary matrix

    .. math::
        \\begin{pmatrix}
        e^{-i \\theta / 2} & 0 \\\\
        0 & e^{i \\theta / 2} \\\\
        \\end{pmatrix}

    Args:
        q (int): the qubit id number.
        theta (float): the rotation angle.
    """

    def __init__(self, q, theta):
        super(RZ, self).__init__()
        self.name = "rz"
        self.target_qubits = (q,)
        self.theta = theta

        self._init_args = [q]
        self._init_kwargs = {"theta": theta}


class CNOT(Gate):
    """The Controlled-NOT gate.

    Args:
        q0 (int): the control qubit id number.
        q1 (int): the target qubit id number.
    """

    def __init__(self, q0, q1):
        super(CNOT, self).__init__()
        self.name = "cx"
        self.control_qubits = (q0,)
        self.target_qubits = (q1,)
        self._init_args = [q0, q1]

    def decompose(self, *free, use_toffolis: bool = True) -> List[Gate]:
        q0, q1 = self.control_qubits[0], self.target_qubits[0]
        return [self.__class__(q0, q1)]


class CZ(Gate):
    """The Controlled-Phase gate.

    Corresponds to the following unitary matrix

    .. math::
        \\begin{pmatrix}
        1 & 0 & 0 & 0 \\\\
        0 & 1 & 0 & 0 \\\\
        0 & 0 & 1 & 0 \\\\
        0 & 0 & 0 & -1 \\\\
        \\end{pmatrix}

    Args:
        q0 (int): the control qubit id number.
        q1 (int): the target qubit id number.
    """

    def __init__(self, q0, q1):
        super(CZ, self).__init__()
        self.name = "cz"
        self.control_qubits = (q0,)
        self.target_qubits = (q1,)
        self._init_args = [q0, q1]


class CZPow(Gate):
    """Controlled rotation around the Z-axis of the Bloch sphere.

    Corresponds to the following unitary matrix

    .. math::
        \\begin{pmatrix}
        1 & 0 & 0 & 0 \\\\
        0 & 1 & 0 & 0 \\\\
        0 & 0 & 1 & 0 \\\\
        0 & 0 & 0 & e^{i \\theta } \\\\
        \\end{pmatrix}

    Note that this differs from the :class:`qibo.base.gates.RZ` gate.

    Args:
        q0 (int): the control qubit id number.
        q1 (int): the target qubit id number.
        theta (float): the rotation angle.
    """

    def __init__(self, q0, q1, theta):
        super(CZPow, self).__init__()
        self.name = "crz"
        self.control_qubits = (q0,)
        self.target_qubits = (q1,)
        self.theta = theta

        self._init_args = [q0, q1]
        self._init_kwargs = {"theta": theta}


class SWAP(Gate):
    """The swap gate.

    Args:
        q0 (int): the first qubit to be swapped id number.
        q1 (int): the second qubit to be swapped id number.
    """

    def __init__(self, q0, q1):
        super(SWAP, self).__init__()
        self.name = "swap"
        self.target_qubits = (q0, q1)
        self._init_args = [q0, q1]


class fSim(Gate):
    """The fSim gate defined in `arXiv:2001.08343 <https://arxiv.org/abs/2001.08343>`_.

    Corresponds to the following unitary matrix

    .. math::
        \\begin{pmatrix}
        1 & 0 & 0 & 0 \\\\
        0 & \\cos \\theta & -i\\sin \\theta & 0 \\\\
        0 & -i\\sin \\theta & \\cos \\theta & 0 \\\\
        0 & 0 & 0 & e^{-i \\phi } \\\\
        \\end{pmatrix}

    Args:
        q0 (int): the first qubit to be swapped id number.
        q1 (int): the second qubit to be swapped id number.
        theta (float): Angle for the one-qubit rotation.
        phi (float): Angle for the |11> phase.
    """
    # TODO: Check how this works with QASM.

    def __init__(self, q0, q1, theta, phi):
        super(fSim, self).__init__()
        self.name = "fsim"
        self.target_qubits = (q0, q1)
        self.theta = theta
        self.phi = phi

        self._init_args = [q0, q1]
        self._init_kwargs = {"theta": theta, "phi": phi}


class GeneralizedfSim(Gate):
    """The fSim gate with a general rotation.

    Corresponds to the following unitary matrix

    .. math::
        \\begin{pmatrix}
        1 & 0 & 0 & 0 \\\\
        0 & R_{00} & R_{01} & 0 \\\\
        0 & R_{10} & R_{11} & 0 \\\\
        0 & 0 & 0 & e^{-i \\phi } \\\\
        \\end{pmatrix}

    Args:
        q0 (int): the first qubit to be swapped id number.
        q1 (int): the second qubit to be swapped id number.
        unitary (np.ndarray): Unitary that corresponds to the one-qubit rotation.
        phi (float): Angle for the |11> phase.
    """

    def __init__(self, q0, q1, unitary, phi):
        super(GeneralizedfSim, self).__init__()
        self.name = "generalizedfsim"
        self.target_qubits = (q0, q1)
        self.unitary = unitary
        self.phi = phi

        self._init_args = [q0, q1]
        self._init_kwargs = {"unitary": unitary, "phi": phi}


class TOFFOLI(Gate):
    """The Toffoli gate.

    Args:
        q0 (int): the first control qubit id number.
        q1 (int): the second control qubit id number.
        q2 (int): the target qubit id number.
    """

    def __init__(self, q0, q1, q2):
        super(TOFFOLI, self).__init__()
        self.name = "ccx"
        self.control_qubits = (q0, q1)
        self.target_qubits = (q2,)
        self._init_args = [q0, q1, q2]

    def decompose(self, *free, use_toffolis: bool = True) -> List[Gate]:
        c0, c1 = self.control_qubits
        t = self.target_qubits[0]
        return [self.__class__(c0, c1, t)]

    def congruent(self, use_toffolis: bool = True) -> List[Gate]:
        """Congruent representation of ``TOFFOLI`` gate.

        This is a helper method for the decomposition of multi-control ``X`` gates.
        The congruent representation is based on Sec. 6.2 of
        `arXiv:9503016 <https://arxiv.org/abs/quant-ph/9503016>`_.
        The sequence of the gates produced here has the same effect as ``TOFFOLI``
        with the phase of the |101> state reversed.

        Args:
            use_toffolis: If ``True`` a single ``TOFFOLI`` gate is returned.
                If ``False`` the congruent representation is returned.

        Returns:
            List with ``RY`` and ``CNOT`` gates that have the same effect as
            applying the original ``TOFFOLI`` gate.
        """
        if use_toffolis:
            return self.decompose()

        import importlib
        import numpy as np
        control0, control1 = self.control_qubits
        target = self.target_qubits[0]
        module = importlib.import_module(self.__module__)
        RY = module.RY
        CNOT = module.CNOT
        return [RY(target, -np.pi / 4), CNOT(control1, target),
                RY(target, -np.pi / 4), CNOT(control0, target),
                RY(target, np.pi / 4), CNOT(control1, target),
                RY(target, np.pi / 4)]


class Unitary(Gate):
    """Arbitrary unitary gate.

    Args:
        unitary: Unitary matrix as a tensor supported by the backend.
            Note that there is no check that the matrix passed is actually
            unitary. This allows the user to create non-unitary gates.
        *q (int): Qubit id numbers that the gate acts on.
        name (str): Optional name for the gate.
    """

    def __init__(self, unitary, *q, name: Optional[str] = None):
        super(Unitary, self).__init__()
        self.name = "Unitary" if name is None else name
        self.unitary = unitary
        self.target_qubits = tuple(q)

        self._init_args = [unitary] + list(q)
        self._init_kwargs = {"name": name}


class VariationalLayer(Gate):
    """Layer of one-qubit parametrized gates followed by two-qubit entangling gates.

    Performance is optimized by fusing the variational one-qubit gates with the
    two-qubit entangling gates that follow them and applying a single layer of
    two-qubit gates as 4x4 matrices.

    Args:
        qubit_pairs (list): List of pairs of qubit IDs on which the two qubit gate act.
        one_qubit_gate: Type of one qubit gate to use as the variational gate.
        two_qubit_gate: Type of two qubit gate to use as entangling gate.
        params_map (dict): Variational parameters of one qubit gates as a dictionary
            that maps qubit IDs to the corresponding parameter value.
        params_map2 (dict): Same as ``params_map`` but for the layer of one-qubit
            gates after the two-qubit gate ones.
        name (str): Optional name for the gate.
            If ``None`` the name ``"VariationalLayer"`` will be used.

    Example:
        ::

            import numpy as np
            from qibo.models import Circuit
            from qibo import gates
            # generate an array of variational parameters for 8 qubits
            theta = 2 * np.pi * np.random.random(8)

            # define qubit pairs that two qubit gates will act
            pairs = [(i, i + 1) for i in range(0, 7, 2)]
            # map variational parameters to qubit IDs
            theta_map = {i: th for i, th in enumerate(theta}
            # define a circuit of 8 qubits and add the variational layer
            c = Circuit(8)
            c.add(gates.VariationalLayer(pairs, gates.RY, gates.CZ, theta_map))
            # this will create an optimized version of the following circuit
            c2 = Circuit(8)
            c.add((gates.RY(i, th) for i, th in enumerate(theta)))
            c.add((gates.CZ(i, i + 1) for i in range(7)))
    """

    def __init__(self, qubit_pairs: List[Tuple[int, int]],
                 one_qubit_gate, two_qubit_gate,
                 params_map: Dict[int, float],
                 params_map2: Optional[Dict[int, float]] = None,
                 name: Optional[str] = None):
        super(VariationalLayer, self).__init__()
        self._init_args = [qubit_pairs, one_qubit_gate, two_qubit_gate]
        self._init_kwargs = {"params_map": params_map,
                             "params_map2": params_map2,
                             "name": name}

        self.name = "VariationalLayer" if name is None else name
        self.params_map = dict(params_map)
        targets = set(self.params_map.keys())
        self.target_qubits = tuple(targets)
        if params_map2 is not None:
            self.params_map2 = dict(params_map2)
            if targets != set(self.params_map2.keys()):
                raise ValueError("Invalid parameter maps given in variational layer.")
        else:
            self.params_map2 = None

        self.qubit_pairs = qubit_pairs
        two_qubit_targets = set(q for p in qubit_pairs for q in p)
        additional_targets = targets - two_qubit_targets
        if not additional_targets:
            self.additional_target = None
        elif len(additional_targets) == 1:
            self.additional_target = additional_targets.pop()
        else:
            raise ValueError("Variational layer can have at most one additional "
                             "target for one qubit gates but has {}."
                             "".format(additional_targets))

        self.one_qubit_gate = one_qubit_gate
        self.two_qubit_gate = two_qubit_gate

        self.unitaries = []
        self.additional_unitary = None


class NoiseChannel(Gate):
    """Probabilistic noise channel.

    Implements the following evolution

    .. math::
        \\rho \\rightarrow (1 - p_x - p_y - p_z) \\rho + p_x X\\rho X + p_y Y\\rho Y + p_z Z\\rho Z

    which can be used to simulate phase flip and bit flip errors.

    Args:
        q (int): Qubit id that the noise acts on.
        px (float): Bit flip (X) error probability.
        py (float): Y-error probability.
        pz (float): Phase flip (Z) error probability.
    """

    def __init__(self, q, px=0, py=0, pz=0):
        super(NoiseChannel, self).__init__()
        self.name = "NoiseChannel"
        self.is_channel = True
        self.target_qubits = (q,)
        self.p = (px, py, pz)
        self.total_p = sum(self.p)

        self._init_args = [q]
        self._init_kwargs = {"px": px, "py": py, "pz": pz}

    def controlled_by(self, *q):
        """"""
        raise ValueError("Noise channel cannot be controlled on qubits.")


class GeneralChannel(Gate):
    """General channel defined by arbitrary Krauss operators.

    Implements the following evolution

    .. math::
        \\rho \\rightarrow \\sum _k A_k \\rho A_k^\\dagger

    where A are arbitrary Krauss operators given by the user. Note that the
    Krauss operators set should be trace preserving, however this is not checked here.
    For more information on channels and Krauss operators please check
    `J. Preskill's notes <http://www.theory.caltech.edu/people/preskill/ph219/chap3_15.pdf>`_.

    Args:
        A (list): List of Krauss operators as pairs ``(qubits, Ak)`` where
          qubits are the qubit ids that ``Ak`` acts on and ``Ak`` is the
          corresponding matrix.

    Example:
        ::

            from qibo.models import Circuit
            from qibo import gates
            # initialize circuit with 3 qubits
            c = Circuit(3)
            # define a sqrt(0.4) * X gate
            a1 = np.sqrt(0.4) * np.array([[0, 1], [1, 0]])
            # define a sqrt(0.6) * CNOT gate
            a2 = np.sqrt(0.6) * np.array([[1, 0, 0, 0], [0, 1, 0, 0],
                                          [0, 0, 0, 1], [0, 0, 1, 0]])
            # define the channel rho -> 0.4 X{1} rho X{1} + 0.6 CNOT{0, 2} rho CNOT{0, 2}
            channel = gates.GeneralChannel([((1,), a1), ((0, 2), a2)])
            # add the channel to the circuit
            c.add(channel)
    """

    def __init__(self, A):
        super(GeneralChannel, self).__init__()
        self.name = "GeneralChannel"
        self.is_channel = True
        self.target_qubits = tuple(sorted(set(
          q for qubits, _ in A for q in qubits)))
        self._init_args = [A]

        # Check that given operators have the proper shape
        for qubits, matrix in A:
            rank = 2 ** len(qubits)
            shape = tuple(matrix.shape)
            if shape != (rank, rank):
                raise ValueError("Invalid Krauss operator shape {} for acting "
                                 "on {} qubits.".format(shape, len(qubits)))

    def controlled_by(self, *q):
        """"""
        raise ValueError("Channel cannot be controlled on qubits.")


class Flatten(Gate):
    """Passes an arbitrary state vector in the circuit.

    Args:
        coefficients (list): list of the target state vector components.
            This can also be a tensor supported by the backend.
    """

    def __init__(self, coefficients):
        super(Flatten, self).__init__()
        self.name = "Flatten"
        self.coefficients = coefficients
        self._init_args = [coefficients]
        self.is_special_gate = True


class CallbackGate(Gate):
    """Calculates a :class:`qibo.tensorflow.callbacks.Callback` at a specific point in the circuit.

    This gate performs the callback calulation without affecting the state vector.

    Args:
        callback (:class:`qibo.tensorflow.callbacks.Callback`): Callback object to calculate.
    """

    def __init__(self, callback: "Callback"):
        super(CallbackGate, self).__init__()
        self.name = callback.__class__.__name__
        self.callback = callback
        self._init_args = [callback]
        self.is_special_gate = True

    @Gate.nqubits.setter
    def nqubits(self, n: int):
        Gate.nqubits.fset(self, n) # pylint: disable=no-member
        self.callback.nqubits = n
